package ucc.reports;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import ucc.logging.Log4j2ConfigurationFactory;
/**
 * WARN, INFO, SYSTEM DUMP COUNTS ARE NOT IMPLEMENTED YET
 * @author rithesh
 * Year: 2016
 *
 */
		
public class PerformanceReport {
	//Time to build file list
	public static long timeBuildFileList=0;
	
	//Time to Read, Analyze & Count
	public static long timeRAC=0;
	 
	//Time to Find duplicates
	public static long timeDup=0;
	
	//Time to Generate results files
	public static long timeResult=0;
	
	//Total Time
	public static long totalTime=0;
	
	//Counts
	public static long stackDumps=0;
	public static long errors=0;
	public static long warnings=0;
	public static long information=0;
	public static long uncountedFiles=0;
	
	//Log filename
	public static String outdir=null;
	public static String plogfileName=null;
	
	public static void printReport(){
		PrintWriter writer = null;
		getCounts();
		try{
			plogfileName = GetLogFileName(outdir);
			writer = new PrintWriter(plogfileName, "UTF-8");
			writer.println(" Processing  Step         :  seconds");
			writer.println("------------------------- : --------");
			writer.println(" Build file list          :      "+timeBuildFileList/1000.0);
			writer.println(" Read, Analyze & Count    :      "+timeRAC/1000.0);
			writer.println(" Find duplicates          :      "+timeDup/1000.0);
			writer.println(" Generate results files   :      "+timeResult/1000.0);
			writer.println("------------------------- : --------");
			//writer.println("               Total time :      "+ totalTime/1000000000.0);
			writer.printf("               Total time :      %.3f\n\n\n", totalTime/1000000000.0);
			writer.println("    Stack Dumps:  "+stackDumps);
			writer.println("         Errors:  "+errors);
			writer.println("       Warnings:  "+warnings);
			writer.println("    Information:  "+information);
			writer.println("Uncounted Files:  "+uncountedFiles);
		}catch (Exception e){
		   System.out.println(e.getMessage());
		}finally{
			if(writer != null){
				writer.close();
			}
		}
	}
	public static void getCounts(){
		String fileName = Log4j2ConfigurationFactory.GetFileName();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(fileName));
		} catch (FileNotFoundException e) {
			return;
		}
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				if(line.contains("ERROR")){
					errors++;
				}
				else if(line.contains("INFO")){
					information++;
				}
				else if(line.contains("WARN")){
					warnings++;
				}
			}
		} catch (IOException e) {
			try {
				br.close();
			} catch (IOException e1) {
				return;
			}
			return;
		}
		try {
			br.close();
		} catch (IOException e) {
			return;
		}
		
		
	}
   public static String GetLogFileName(String outdir)
   {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH\uA789mm\uA789ss");
      return (outdir + "/" + dateFormat.format(new Date())+ "-ucc-performance.log");      
   }
}
